from flask import Flask, request, jsonify
from flask_cors import CORS
from trans_api import trans
from qa_api import qa
import json

app = Flask(__name__)
CORS(app)  # Enable CORS for the Flask app

@app.route('/questions', methods=['POST'])
def Question_Genration():
    try:
        # Get the JSON data from the request body
        data = request.get_json()

        # Extract the URL from the data
        url = data.get('url')

        # Check if the URL is provided
        if url is None:
            return jsonify({'error': 'URL is required'}), 400
        transcription=trans(url)
        print(transcription)
        result_value = transcription["result"]
        qeustions=qa(result_value)
        print(qeustions)
        result_valu = qeustions["result"]
        print("\nfinal output\n") 
        print(result_valu)
        print(type(result_valu))
        data = json.loads(result_valu)
        for item in data:
            item['answer'] = ""
        print(json.dumps(data, indent=4))

        # Sample questions and answers
        short_questions = data
        mcqs = []

        # Return the result as a JSON response
        return jsonify({
            'short_questions': short_questions,
            'mcqs': mcqs
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5002)
