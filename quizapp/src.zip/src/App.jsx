import React from "react";
import Header from "./Components/Assets/Header/Header.jsx";
import LandingPage from "./Components/Assets/Landingpage/Landingpage.jsx";
import LoginSignup from "./Components/Assets/LoginSignup/LoginSignup.jsx";
import Homepage from "./Components/Assets/pages/Home.jsx";
import About from "./Components/Assets/pages/Aboutus.jsx";
import Contact from "./Components/Assets/pages/Contact.jsx";
import Services from "./Components/Assets/pages/Services.jsx";
import './App.css'
import {Route, Routes} from "react-router-dom"
import Summarize from "./Components/Assets/pages/Summarizer/Summarize.jsx";
import TestModal from "./Components/Assets/pages/TestModal.jsx";
import Modal from 'react-modal';

Modal.setAppElement('#root'); // Set the app element globally

function App() {
    let components 

    
    return (
        <div className="App">

            <Header></Header>
            <div className="containerForPages">
            <Routes>
                <Route path="/home" element={<Homepage/>}></Route>
                <Route path="/" element={<Homepage/>}></Route>
                <Route path="/about" element={<About/>}></Route>
                <Route path="/services" element={<Services/>}></Route>
                <Route path="/contact" element={<Contact/>}></Route>
                <Route path="/summarize" element={<Summarize/>}></Route>
            </Routes>
            </div>



            
        </div>
    );
}

export default App;
