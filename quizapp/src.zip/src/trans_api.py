import requests
def trans(reference_text):
    url = 'https://1ff8-34-170-101-3.ngrok-free.app/translate'
    data = {'url': reference_text}

    response = requests.post(url, json=data)
    result = response.json()
    print(f"{result['result']}")
    return result

