import React, { useState } from "react";
import "./Summarize.css";
import TempTakeQuiz from "./TempTakeQuiz";
import Summary from "./Summary";
import GettingInput from "./GettingInput";
import Modal from "react-modal";

// Ensure that you set the app element to avoid screen readers reading outside the modal
Modal.setAppElement('#root');

export default function Summarize() {
    const [visible, setVisible] = useState(false);
    const [apiResponse, setApiResponse] = useState(null);  // State to store the API response
    const [loading, setLoading] = useState(false);  // Loading state for the spinner

    // Handle the API response from GettingInput component
    const handleApiResponse = (response) => {
        console.log("Received API Response:", response);  // Debugging log
        setApiResponse(response);  // Set the response to state
        setLoading(false);  // Stop loading when the response is received
    };

    const handleStartLoading = () => {
        console.log("Loading started...");
        setLoading(true);  // Start loading when API request is initiated
    };

    const checkQuizQuit = () => {
        // Display confirmation dialog
        const userConfirmed = window.confirm("You are about to leave the Quiz. Do you want to proceed?");
    
        // If user confirms, proceed with closing the modal
        if (userConfirmed) {
            setVisible(false);
        }
        // If user cancels, do nothing
    };

    return (
        <div className="containerForWork">
            <GettingInput 
                onApiResponse={handleApiResponse} 
                onStartLoading={handleStartLoading} 
            />  {/* Pass the callback */}

            <div className="take-quiz-container">
                <Summary />
                <div className="QuizPopUpDiv">
                    {loading ? (
                        <div className="spinner"></div>  // Show spinner while loading
                    ) : (
                        <button 
                            onClick={() => {
                                console.log("Starting Quiz");
                                setVisible(true);
                            }} 
                            disabled={!apiResponse}  // Button is disabled if apiResponse is null
                        >
                            Start Quiz
                        </button>
                    )}

                    <Modal
                        isOpen={visible && apiResponse}  // Open modal only if visible and apiResponse is available
                        onRequestClose={() => setVisible(false)}
                        className="fixed inset-0 flex justify-center items-center p-4"
                        overlayClassName="fixed inset-0 bg-black bg-opacity-30 backdrop-blur-sm"
                        shouldCloseOnOverlayClick={true} // Ensures clicking on the overlay closes the modal
                    >
                        <div className="bg-transparent p-0 rounded-lg relative">
                            {/* Cross Icon */}
                            <button 
                                onClick={checkQuizQuit} 
                                className="absolute top-2 right-2 text-4xl font-bold text-gray-500 hover:text-gray-700 p-2"
                            >
                                &times;
                            </button>
                            {/* Render TempTakeQuiz only if apiResponse is not null */}
                            {apiResponse && <TempTakeQuiz apiResponse={apiResponse} />}
                        </div>
                    </Modal>
                </div>
            </div>
        </div>
    );
}
