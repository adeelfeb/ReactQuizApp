
import { useState, useRef } from "react"
import "./TakeQuiz.css"
import {data} from "./QuizAssets/data"

export default function TakeQuiz(){


    return(<div>

    </div>)
};