import LogginSignup from "../LoginSignup/LoginSignup"


export default function about(){
    return(
        <div>
            <LogginSignup></LogginSignup>
        </div>
    )
}

