export default function Contact(){
    return(
        <div>
            <h1 style={{textAlign:"center"}}>Contact Us</h1>
        </div>
    )
}

